package modelo;

public interface IRangoEtario {

	
	boolean prioridad(Paciente otro);
	
	boolean prioridadNi�o();
	
	boolean prioridadJoven();
	
	boolean prioridadMayor();
}

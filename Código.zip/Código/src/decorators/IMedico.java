package decorators;

public interface IMedico {

long getNroMatricula();
double getHonorario();
String getNombre();
}
